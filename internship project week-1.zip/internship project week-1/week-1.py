import pandas as pd

# Load the Excel Dataset
file_path = "Dataset for Data Analytics.xlsx"

# read excel file
df = pd.read_excel(file_path)

# display first 5 rows
print(df.head())

# Check Dataset Information

# dataset structure 
print(df.info())

# checking missing number
print(df.isnull().sum())

# Handle Missing Values

# Fill text columns with "Unknown"
text_columns = ['ShippingAddress', 'CouponCode', 'ReferralSource']
for col in text_columns:
    df[col] = df[col].fillna('UnKnown')


# Fill numeric columns with median
numeric_columns = ['Quantity', 'UnitPrice', 'ItemsInCart', 'TotalPrice']
for col in numeric_columns:
    df[col] = df[col].fillna(df[col].median())


# Remove Duplicate Records

# # Check duplicate rows
print('duplicate rows: ', df.duplicated().sum())

df = df.drop_duplicates()

# Check Duplicate IDs

print('duplicates IDs :', df['OrderID'].duplicated().sum())

df = df.drop_duplicates(subset='OrderID')

# Correct Date Format

# Convert Date column to datetime

df['Date'] = pd.to_datetime(df['Date'],errors='coerce')

# Check invalid dates
print(df['Date'].isnull().sum())

# Standardize Text Columns

# Convert text columns to proper format
text_cols = ['Product', 'PaymentMethod', 'OrderStatus','ReferralSource']

for col in text_cols:
    df[col] = df[col].astype(str).str.strip().str.title()


# Verify Numeric Columns
numeric_cols = ['Quantity', 'UnitPrice', 'ItemsInCart', 'TotalPrice']

for col in numeric_cols:
    df[col] = pd.to_numeric(df[col], errors='coerce')


# Final Validation Checks

print("\nFINAL VALIDATION")
print("===================")

print('\nMissing Values')
print(df.isnull().sum())


print('\nduplicate Rows')
print(df.duplicated().sum())

print('\nDuplicate Order Id')
print(df['OrderID'].duplicated().sum())


# Save Cleaned Dataset

output_file = 'Mehran_Final_Cleaned_Data.xlsx'
df.to_excel(output_file, index=False)
print('cleaned dataset save successfully')